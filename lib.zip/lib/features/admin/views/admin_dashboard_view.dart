import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:dashbord2/features/drawer/drawer_page.dart';
import 'package:dashbord2/features/panel_center/panel_center_page.dart';
import 'package:dashbord2/features/panel_right/panel_right_page.dart';
import 'package:dashbord2/features/widgets/app_bar_widget.dart';
import 'package:dashbord2/features/widgets/responsive_layout.dart';
import 'package:flutter/material.dart';
import '../../../core/constants/app_constants.dart';
import '../../panel_lift/panel_lift_page.dart';
import '../controllers/admin_dashboard_controller.dart';
import 'package:get/get.dart';
class AdminDashboardView extends StatefulWidget {
  const AdminDashboardView({super.key});

  @override
  State<AdminDashboardView> createState() => _AdminDashboardViewState();
}

class _AdminDashboardViewState extends State<AdminDashboardView> {
  final AdminDashboardController ctrl = Get.find<AdminDashboardController>();
  int currentIndex = 1;
  int currentIndex2 = 0;

  final List<Widget> _icons = [
    Icon(Icons.add, size: 30),
    Icon(Icons.list, size: 30),
    Icon(Icons.compare_arrows, size: 30),
  ];
  final List<Widget> _icons2 = [
    Icon(Icons.add, size: 30),
    Icon(Icons.compare_arrows, size: 30),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size(double.infinity, 100),
        child:
        (ResponsiveLayout.isTinyLimit(context) ||
            ResponsiveLayout.isTinyHeightLimit(context)
            ? Container()
            : AppBarWidget()),
      ),
      body: ResponsiveLayout(
        tiny: Container(),
        phone: currentIndex == 0
            ? PanelLiftPage()
            : currentIndex == 1
            ? PanelCenterPage()
            : PanelRightPage(),
        tablet: currentIndex2 == 0
            ? Row(
          children: [
            Expanded(child: PanelLiftPage()),
            Expanded(child: PanelCenterPage()),
          ],
        )
            : Row(
          children: [
            Expanded(child: PanelCenterPage()),
            Expanded(child: PanelRightPage()),
          ],
        ),
        largeTablet: Row(
          children: [
            Expanded(child: PanelLiftPage()),
            Expanded(child: PanelCenterPage()),
            Expanded(child: PanelRightPage()),
          ],
        ),
        computer: Row(
          children: [
            Expanded(child: DrawerPage()),
            Expanded(child: PanelLiftPage()),
            Expanded(child: PanelCenterPage()),
            Expanded(child: PanelRightPage()),
          ],
        ),
      ),
      drawer: DrawerPage(),
      bottomNavigationBar: ResponsiveLayout.isPhone(context)
          ? CurvedNavigationBar(
        items: _icons,
        index: currentIndex,
        backgroundColor: Constants.backgroundDark,
        color: Constants.accent,
        buttonBackgroundColor: Constants.accent,
        onTap: (index) {
          setState(() {
            currentIndex = index;
          });
        },
      )
          : ResponsiveLayout.isTablet(context)
          ? CurvedNavigationBar(
        items: _icons2,
        index: currentIndex2,
        backgroundColor: Constants.backgroundDark,
        color: Constants.accent,
        buttonBackgroundColor: Constants.accent,
        onTap: (index) {
          setState(() {
            currentIndex2 = index;
          });
        },
      )
          : SizedBox(),
    );
  }
}
