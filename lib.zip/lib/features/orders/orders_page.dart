import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../admin/controllers/admin_dashboard_controller.dart';
import '../drawer/drawer_page.dart';

class OrdersPage extends StatefulWidget {
  const OrdersPage({super.key});

  @override
  State<OrdersPage> createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage> {
  final AdminDashboardController ctrl = Get.find<AdminDashboardController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const DrawerPage(),
      appBar: AppBar(
        title: const Text("أدارة الطلبات"),
        backgroundColor: Colors.green,
      ),
      body: Obx(
            () => ctrl.pages[ctrl.selectedIndex.value],
      ),
    );
  }
}
