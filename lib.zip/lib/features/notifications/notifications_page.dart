import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:get/get.dart';
import '../admin/controllers/admin_dashboard_controller.dart';
import '../drawer/drawer_page.dart';

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});

  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  final AdminDashboardController ctrl = Get.find<AdminDashboardController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const DrawerPage(),
      appBar: AppBar(
        title: const Text("إدارة الاشعارات"),
        backgroundColor: Colors.green,
      ),
      body: Obx(
            () => ctrl.pages[ctrl.selectedIndex.value],
      ),
    );
  }
}
