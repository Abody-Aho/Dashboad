import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../admin/controllers/admin_dashboard_controller.dart';
import '../drawer/drawer_page.dart';

class ProductsPage extends StatefulWidget {
  const ProductsPage({super.key});

  @override
  State<ProductsPage> createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  final AdminDashboardController ctrl = Get.find<AdminDashboardController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const DrawerPage(),
      appBar: AppBar(
        title: const Text("إدارة المنتجات"),
        backgroundColor: Colors.green,
      ),
      body: Obx(
            () => ctrl.pages[ctrl.selectedIndex.value],
      ),
    );
  }
}
