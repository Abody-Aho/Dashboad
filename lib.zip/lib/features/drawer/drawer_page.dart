import 'package:dashbord2/features/widgets/responsive_layout.dart';
import 'package:flutter/material.dart';

import '../../core/constants/app_constants.dart';

class DrawerPage extends StatefulWidget {
  const DrawerPage({super.key});

  @override
  State<DrawerPage> createState() => _DrawerPageState();
}

class ButtonsInfo {
  String title;
  IconData icon;

  ButtonsInfo({required this.title, required this.icon});
}

int _currentIndex = 0;

final List<ButtonsInfo> buttonsInfo = [
  ButtonsInfo(title: "الرئيسية", icon: Icons.home),
  ButtonsInfo(title: "إدارة المستخدمين", icon: Icons.people),
  ButtonsInfo(title: "إدارة السوبرماركت", icon: Icons.store),
  ButtonsInfo(title: "إدارة الطلبات", icon: Icons.shopping_bag),
  ButtonsInfo(title: "إدارة المنتجات", icon: Icons.inventory_2),
  ButtonsInfo(title: "إدارة الدفع", icon: Icons.payment),
  ButtonsInfo(title: "الإشعارات", icon: Icons.notifications),
  ButtonsInfo(title: "تسجيل الخروج", icon: Icons.logout),
];

class _DrawerPageState extends State<DrawerPage> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.green[50],
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(Constants.kPadding),
          child: Column(
            children: [
              ListTile(
                title: Text(
                  "Admin Menu",
                  style: TextStyle(color: Constants.text),
                ),
                trailing: ResponsiveLayout.isComputer(context)
                    ? null
                    : IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: Icon(Icons.close, color: Constants.primary),
                      ),
              ),
              ...List.generate(
                buttonsInfo.length,
                (index) => Column(
                  children: [
                    Container(
                      decoration: index == _currentIndex ? BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        gradient: LinearGradient(
                          colors: [?Colors.green[100], ?Colors.green[100]],
                        ),
                      ) : null,
                      child: ListTile(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        title: Text(buttonsInfo[index].title,style: TextStyle(color: Constants.text),),
                        leading: Icon(buttonsInfo[index].icon,color: Constants.primary,),
                        onTap: () {
                          setState(() {
                            _currentIndex = index;
                          });
                        }
                      ),
                    ),
                    Divider(
                      color: Constants.primary,
                      thickness: 0.1,
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
