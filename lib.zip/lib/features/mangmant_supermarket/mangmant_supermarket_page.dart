import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../admin/controllers/admin_dashboard_controller.dart';
import '../drawer/drawer_page.dart';

class MangmantSupermarketPage extends StatefulWidget {
  const MangmantSupermarketPage({super.key});

  @override
  State<MangmantSupermarketPage> createState() => _MangmantSupermarketPageState();
}

class _MangmantSupermarketPageState extends State<MangmantSupermarketPage> {
  // نستخدم النسخة الموجودة مسبقًا من الـ Controller
  final AdminDashboardController ctrl = Get.find<AdminDashboardController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const DrawerPage(),
      appBar: AppBar(
        title: const Text("إدارة السوبرماركت"),
        backgroundColor: Colors.green,
      ),
      body: Obx(
            () => ctrl.pages[ctrl.selectedIndex.value],
      ),
    );
  }
}
